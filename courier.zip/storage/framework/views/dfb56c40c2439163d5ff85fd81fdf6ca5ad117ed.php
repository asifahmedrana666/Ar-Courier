
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">



<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Dashboard</h1> 


            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Today Report</li>
            </ol>

                   
       <?php if(auth()->user()->type=='Merchant'): ?>
            <div class="row">



                <div class="col-xl-3 col-md-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                         
          <h3><?php echo e(0+$mdptoday[0]->total); ?></h3>                                              

                          <p>Total Due Today</p>
                        </div>
                        <div class="icon">
                          <i class="fas fa-shopping-cart"></i>
                        </div>
                        <a href="#" class="small-box-footer">
                          More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                      </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="small-box bg-gradient-success">
                        <div class="inner">
                         
          <h3><?php echo e(0+$mdpyesterday[0]->total); ?></h3>                                              

                          <p>Total Due Yesterday</p>
                        </div>
                        <div class="icon">
                          <i class="fas fa-user-plus"></i>
                        </div>
                        <a href="#" class="small-box-footer">
                          More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                      </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                          
          <h3><?php echo e(0+$mdptotal[0]->total); ?></h3>                                              

                          <p>Total Due</p>
                        </div>
                        <div class="icon">
                          <i class="fas fa-shopping-cart"></i>
                        </div>
                        <a href="#" class="small-box-footer">
                          More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                      </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                      
          <h3>Waiting</h3>                                              

                          <p>For Payment</p>
                        </div>
                        <div class="icon">
                          <i class="fas fa-user-plus"></i>
                        </div>
                        <a href="#" class="small-box-footer">
                          More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                      </div>
                </div>
            </div>

            <?php endif; ?>
            

                               
       <?php if(auth()->user()->type=='Admin'): ?>
       <div class="row">



           <div class="col-xl-3 col-md-6">
               <div class="small-box bg-danger">
                   <div class="inner">
                    
     <h3><?php echo e(0+$admintoday[0]->total); ?></h3>                                              

                     <p>Total Due Today</p>
                   </div>
                   <div class="icon">
                     <i class="fas fa-shopping-cart"></i>
                   </div>
                   <a href="#" class="small-box-footer">
                     More info <i class="fas fa-arrow-circle-right"></i>
                   </a>
                 </div>
           </div>
           <div class="col-xl-3 col-md-6">
               <div class="small-box bg-gradient-success">
                   <div class="inner">
                    
     <h3><?php echo e(0+$adminyesterday[0]->total); ?></h3>                                              

                     <p>Total Due Yesterday</p>
                   </div>
                   <div class="icon">
                     <i class="fas fa-user-plus"></i>
                   </div>
                   <a href="#" class="small-box-footer">
                     More info <i class="fas fa-arrow-circle-right"></i>
                   </a>
                 </div>
           </div>
           <div class="col-xl-3 col-md-6">
               <div class="small-box bg-info">
                   <div class="inner">
                     
     <h3><?php echo e(0+$admintotal[0]->total); ?></h3>                                              

                     <p>Total Due</p>
                   </div>
                   <div class="icon">
                     <i class="fas fa-shopping-cart"></i>
                   </div>
                   <a href="#" class="small-box-footer">
                     More info <i class="fas fa-arrow-circle-right"></i>
                   </a>
                 </div>
           </div>
           <div class="col-xl-3 col-md-6">
               <div class="small-box bg-warning">
                   <div class="inner">
                 
     <h3>Waiting</h3>                                              

                     <p>For Payment</p>
                   </div>
                   <div class="icon">
                     <i class="fas fa-user-plus"></i>
                   </div>
                   <a href="#" class="small-box-footer">
                     More info <i class="fas fa-arrow-circle-right"></i>
                   </a>
                 </div>
           </div>
       </div>

       <?php endif; ?>
       
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                       
                       <?php if(auth()->user()->type=='Merchant'): ?>
                        <tr>
                            <th>SN</th>
                            <th>Customar Name</th>
                            <th>Customar Phone</th>
                            <th>Customar Address</th>
                            <th>Due</th>
                            <th>Status</th>
                            
                        </tr>
                        <?php endif; ?>
                         
                          
                       <?php if(auth()->user()->type=='Admin'): ?>
                       <tr>
                           <th>SN</th>
                           <th>Merchant Name</th>
                           <th>Customar Name</th>
                           <th>Customar Phone</th>
                           <th>Customar Address</th>
                           <th>Due</th>
                           <th>Status</th>
                           <th>Action</th>
                       </tr>
                       <?php endif; ?>
                        
                    </thead>

                    
                    <tbody>
                       
                        
                        <?php if(auth()->user()->type=='Merchant'): ?>
                           <?php $__currentLoopData = $alldueshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$alldueshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            
                            <td><?php echo e($alldueshow->Recipient_Name); ?></td>
                            <td><?php echo e($alldueshow->Recipient_Phone); ?></td>
                            <td><?php echo e($alldueshow->Recipient_Address); ?></td>
                            <td><?php echo e($alldueshow->Ammount_Collect-$alldueshow->delivery_charge); ?></td>
                            <td>
                                <span class="btn btn-danger">Pending                   <div class="overlay">
                                    <i class="fas fa-0x fa-sync-alt fa-spin"></i>
                                  </div></span>
                            </td>
                            
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                       
                                               
                                               <?php if(auth()->user()->type=='Admin'): ?>
                                               <?php $__currentLoopData = $alladminshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$alladminshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($alladminshow->marcent_name); ?></td>
                                                <td><?php echo e($alladminshow->Recipient_Name); ?></td>
                                                <td><?php echo e($alladminshow->Recipient_Phone); ?></td>
                                                <td><?php echo e($alladminshow->Recipient_Address); ?></td>
                                                <td><?php echo e($alladminshow->Ammount_Collect-$alladminshow->delivery_charge); ?></td>
                                                <td>
                                                    <span class="btn btn-danger">Pending                   <div class="overlay">
                                                        <i class="fas fa-0x fa-sync-alt fa-spin"></i>
                                                      </div></span>
                                                </td>
                                                <td><a href="/due_edit/<?php echo e($alladminshow->id); ?>" class="btn btn-success" role="button" aria-pressed="true">Edit</a></td>
                                            </tr>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                           
                    </tbody>
                </table>
            
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\localhost\courier\resources\views/Merchant_Due_Payment.blade.php ENDPATH**/ ?>