
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<?php $__env->startSection('content'); ?>




<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Total Order</h1>
            
            <?php if(auth()->user()->type=='Admin'): ?>
            <a href="create_order" class="btn btn-success" role="button" aria-pressed="true">Create Order</a>
            <?php endif; ?>
            <?php if(auth()->user()->type=='Merchant'): ?>
            <a href="create_order" class="btn btn-success" role="button" aria-pressed="true">Create Order</a>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    All Order
                </div>

                
                <?php if(auth()->user()->type=='Admin'): ?>
                    <ul class="nav nav-pills nav-fill">

                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary"  href="/order">All Delivery <p class="btn btn-dark"><?php echo e($admintotal); ?></p> </a> 
                    </li>
                        <li class="nav-item">
                          <a class="btn btn-danger"  href="/pending_delivery">Picup Request  <p class="btn btn-dark"><?php echo e($adminpicup); ?></p>  </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-success"  href="/complete_delivery">Complete Delivery <p class="btn btn-dark"><?php echo e($admincomplete); ?></p> </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-info"  href="/Processing_delivery">Out For Delivery <p class="btn btn-dark"><?php echo e($adminout); ?></p> </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-danger"  href="/Retrun_delivery">Retrun <p class="btn btn-dark"><?php echo e($adminRetrun); ?></p> </a>
                        </li>
                    </li>
                        <li class="nav-item">
                            <a class="btn btn-warning"  href="/holddelivery">Hold <p class="btn btn-dark"><?php echo e($adminhold); ?></p> </a>
                        </li>
                      </ul>
                      <?php endif; ?>
       
 
 <?php if(auth()->user()->type=='Merchant'): ?>
 <ul class="nav nav-pills nav-fill">

 </li>
 <li class="nav-item">
     <a class="btn btn-primary"  href="/order">All Delivery <p class="btn btn-dark"><?php echo e($total_order); ?></p> </a> 
 </li>
     <li class="nav-item">
       <a class="btn btn-danger"  href="/pending_delivery">Picup Request  <p class="btn btn-dark"><?php echo e($pending_delivery); ?></p>  </a>
     </li>
     <li class="nav-item">
         <a class="btn btn-success"  href="/complete_delivery">Complete Delivery <p class="btn btn-dark"><?php echo e($complete_delivery); ?></p> </a>
     </li>
     <li class="nav-item">
         <a class="btn btn-info"  href="/Processing_delivery">Out For Delivery <p class="btn btn-dark"><?php echo e($Processing_delivery); ?></p> </a>
     </li>
     <li class="nav-item">
         <a class="btn btn-danger"  href="/Retrun_delivery">Retrun <p class="btn btn-dark"><?php echo e($Retrun_delivery); ?></p> </a>
     </li>
 </li>
     <li class="nav-item">
         <a class="btn btn-warning"  href="/holddelivery">Hold <p class="btn btn-dark"><?php echo e($hold_delivery); ?></p> </a>
     </li>
   </ul>
   <?php endif; ?>


<?php if(auth()->user()->type=='Rider'): ?>
<ul class="nav nav-pills nav-fill">

</li>
<li class="nav-item">
    <a class="btn btn-primary"  href="/order">All Delivery <p class="btn btn-dark"><?php echo e($riderall); ?></p> </a> 
</li>
    <li class="nav-item">
      <a class="btn btn-danger"  href="/pending_delivery">Picup Request  <p class="btn btn-dark"><?php echo e($riderpicup); ?></p>  </a>
    </li>
    <li class="nav-item">
        <a class="btn btn-success"  href="/complete_delivery">Complete Delivery <p class="btn btn-dark"><?php echo e($ridercomplete); ?></p> </a>
    </li>
    <li class="nav-item">
        <a class="btn btn-info"  href="/Processing_delivery">Out For Delivery <p class="btn btn-dark"><?php echo e($riderout); ?></p> </a>
    </li>
    <li class="nav-item">
        <a class="btn btn-danger"  href="/Retrun_delivery">Retrun <p class="btn btn-dark"><?php echo e($riderRetrun); ?></p> </a>
    </li>
</li>
    <li class="nav-item">
        <a class="btn btn-warning"  href="/holddelivery">Hold <p class="btn btn-dark"><?php echo e($riderhold); ?></p> </a>
    </li>
  </ul>
  <?php endif; ?>




                      
                
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            
                            <?php if(auth()->user()->type=='Admin'): ?>
                            <tr>
                                <th>SN</th>
                                <th>Merchant Name</th>
                                <th>Picup Address</th>
                                <th>Customar Name</th>
                                <th>Customar Phone</th>
                                <th>Customar Address</th>
                                <th>Ammount To Collect</th>
                                <th>Status</th>
                                <th>Action</th>
                                
                            </tr>
                            <?php endif; ?>
                            
                            
                            <?php if(auth()->user()->type=='Merchant'): ?>
                            <tr>
                                <th>SN</th>
                                <th>Customar Name</th>
                                <th>Customar Phone</th>
                                <th>Customar Address</th>
                                <th>Delivery Charge</th>
                                <th>Ammount To Collect</th>
                                <th>Status</th>
                                <th>Action</th>
                                
                            </tr>
                            <?php endif; ?>
                            
                            
                            <?php if(auth()->user()->type=='Rider'): ?>
                            <tr>
                                <th>SN</th>
                                <th>Customar Name</th>
                                <th>Customar Phone</th>
                                <th>Customar Address</th>
                                <th>Ammount To Collect</th>
                                <th>Status</th>
                                <th>Action</th>
                                
                            </tr>
                            <?php endif; ?>
                            
                        </thead>
                    
                        <tbody>
                            
                            <?php if(auth()->user()->type=='Admin'): ?>
                            <?php $__currentLoopData = $adminorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$adminorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($adminorder->marcent_name); ?></td>
                                <td><?php echo e($adminorder->picup_address); ?></td>
                                <td><?php echo e($adminorder->Recipient_Name); ?></td>
                                <td><?php echo e($adminorder->Recipient_Phone); ?></td>
                                <td><?php echo e($adminorder->Recipient_Address); ?></td>
                                <td><?php echo e($adminorder->Ammount_Collect); ?></td>
                                <td>
                                    <?php if($adminorder->status==0): ?>
                                    <h5><span class="badge btn btn-danger">Picup Reques</span></h5>
                                      <?php elseif($adminorder->status==1): ?>
                                      <h5><span class="badge btn btn-info ">Pending </span></h5>
                                     <?php elseif($adminorder->status==2): ?>
                                      <h5><span  class="badge btn btn-primary  ">Out For Delivery </span></h5>
                                       <?php elseif($adminorder->status==3): ?>
                                       <h5> <span  class="badge btn btn-warning">Hold</span> </h5>
                                        <?php elseif($adminorder->status==4): ?>
                                        <h5> <span  class="badge btn btn-danger">Retrun</span> </h5>
                                     <?php else: ?>
                                     <h5> <span  class="badge btn btn-success">Deliverd</span> </h5>
                                     <?php endif; ?>
                                
                                   </td>
                                   <td>
                                    <a href="/edit_order/<?php echo e($adminorder->id); ?>" class="btn btn-success" role="button" aria-pressed="true">Edit</a>
                                    <a href="/delete_order/<?php echo e($adminorder->id); ?>" class="btn btn-danger" role="button" aria-pressed="true">Delete</a>
                                    <a href="/viewinvoice/<?php echo e($adminorder->id); ?>" class="btn btn-info" role="button" aria-pressed="true">View</a>
                                    <a href="/tracking/<?php echo e($adminorder->id); ?>" class="btn btn-warning" role="button" aria-pressed="true">Track</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                             
                             <?php if(auth()->user()->type=='Merchant'): ?>
                             <?php $__currentLoopData = $merchantorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$merchantorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($key+1); ?></td>
                                 <td><?php echo e($merchantorder->Recipient_Name); ?></td>
                                 <td><?php echo e($merchantorder->Recipient_Phone); ?></td>
                                 <td><?php echo e($merchantorder->Recipient_Address); ?></td>
                                 <td><?php echo e($merchantorder->delivery_charge); ?></td>
                                 <td><?php echo e($merchantorder->Ammount_Collect); ?></td>
                                 <td>
                                    <?php if($merchantorder->status==0): ?>
                                    <h5><span class="badge btn btn-danger">Picup Reques</span></h5>
                                      <?php elseif($merchantorder->status==1): ?>
                                      <h5><span class="badge btn btn-info ">Pending </span></h5>
                                     <?php elseif($merchantorder->status==2): ?>
                                      <h5><span  class="badge btn btn-primary  ">Out For Delivery </span></h5>
                                       <?php elseif($merchantorder->status==3): ?>
                                       <h5> <span  class="badge btn btn-warning">Hold</span> </h5>
                                        <?php elseif($merchantorder->status==4): ?>
                                        <h5> <span  class="badge btn btn-danger">Retrun</span> </h5>
                                     <?php else: ?>
                                     <h5> <span  class="badge btn btn-success">Deliverd</span> </h5>
                                     <?php endif; ?>
                                 
                                    </td>
                                    <td>
                                     
                                     <a href="/viewinvoice/<?php echo e($merchantorder->id); ?>" class="btn btn-info" role="button" aria-pressed="true">View</a>
                                     <a href="/tracking/<?php echo e($merchantorder->id); ?>" class="btn btn-warning" role="button" aria-pressed="true">Track</a>
                                 </td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                             
                             
                             <?php if(auth()->user()->type=='Rider'): ?>
                             <?php $__currentLoopData = $riderordert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$riderordert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($key+1); ?></td>
                                 <td><?php echo e($riderordert->Recipient_Name); ?></td>
                                 <td><?php echo e($riderordert->Recipient_Phone); ?></td>
                                 <td><?php echo e($riderordert->Recipient_Address); ?></td>
                                 <td><?php echo e($riderordert->Ammount_Collect); ?></td>
                                 <td>
                                    <?php if($riderordert->status==0): ?>
                                    <h5><span class="badge btn btn-danger">Picup Reques</span></h5>
                                      <?php elseif($riderordert->status==1): ?>
                                      <h5><span class="badge btn btn-info ">Pending </span></h5>
                                     <?php elseif($riderordert->status==2): ?>
                                      <h5><span  class="badge btn btn-primary  ">Out For Delivery </span></h5>
                                       <?php elseif($riderordert->status==3): ?>
                                       <h5> <span  class="badge btn btn-warning">Hold</span> </h5>
                                        <?php elseif($riderordert->status==4): ?>
                                        <h5> <span  class="badge btn btn-danger">Retrun</span> </h5>
                                     <?php else: ?>
                                     <h5> <span  class="badge btn btn-success">Deliverd</span> </h5>
                                     <?php endif; ?>
                                 
                                    </td>
                                    <td>
                                     <a href="/edit_order/<?php echo e($riderordert->id); ?>" class="btn btn-success" role="button" aria-pressed="true">Edit</a>
                                     <a href="/viewinvoice/<?php echo e($riderordert->id); ?>" class="btn btn-info" role="button" aria-pressed="true">View</a>
                                    
                                 </td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                             
                        </tbody>

                        
                    </table>


                  
                       
                    
                </div>
            </div>
        </div>




       









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\localhost\courier\resources\views/order.blade.php ENDPATH**/ ?>