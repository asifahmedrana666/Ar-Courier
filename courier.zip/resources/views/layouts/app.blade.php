@include('dash.header')

@yield('content')
@include('dash.footer')